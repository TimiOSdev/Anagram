import UIKit

var dictionary: [String.Element : Int] = [:]
var dictionary2: [String.Element : Int] = [:]
func Anagram(s1: String, s2: String) -> Bool {
    //returns false if count does not match
    if s1.count != s2.count {
        return false
    }
    //Lowercase Value
    let firstWord = s1.lowercased()
    let secondWord = s2.lowercased()
    
    for i in firstWord {
        //if key does not exist it makes key and initial value of 1
        if dictionary.keys.contains(i) != true {
            dictionary[i] = 1
        } else {
        // If the key does exist it will add 1 more each time
            dictionary[i]! += 1
        }
    }
    
    for i in secondWord {
        if dictionary2.keys.contains(i) != true {
            dictionary2[i] = 1
        } else {
            dictionary2[i]! += 1
        }
    }
    if dictionary == dictionary2 {
        return true
    } else {
        return false
    }
}


Anagram(s1: "Timi", s2: "miti")
//
